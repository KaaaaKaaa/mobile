import { Text, SafeAreaView, StyleSheet, Image, TouchableOpacity } from 'react-native';


export default function App() {
  return (
    <SafeAreaView style={styles.container}>
     <Image
        style={styles.imagem}
        source={require('./assets/cronometro.png')}
      />
       <Text style={styles.numero}>
      00:00
      </Text>
      <TouchableOpacity style={styles.botao} >
          <Text>Parar</Text>
        </TouchableOpacity>
<TouchableOpacity style={styles.botao} >
          <Text>Limpar</Text>
        </TouchableOpacity>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    backgroundColor: '#0cb5f2',
    padding: 8,
  },

  imagem: {
    width: 250,
    height: 300,
    justifyContent: 'center',
    margin: 80,
    alignItems: 'center',
    
  },

  numero: {
    marginTop: -230,
    marginBottom: 100,
    fontSize: 50,
    textAlign: 'center',
    color: '#ffffff',
    fontWeight: 'bold',
    
  },
  
  botao: {
    alignItems: 'center',
    backgroundColor: '#ffffff',
    borderRadius: 10,
    padding: 10,
    margin: 5,
    
  },

});
